package com.survey;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineSurveyApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineSurveyApplication.class, args);
	}

}
