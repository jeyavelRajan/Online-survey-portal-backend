import { TestBed } from '@angular/core/testing';

import { ServicequestionService } from './servicequestion.service';

describe('ServicequestionService', () => {
  let service: ServicequestionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ServicequestionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
