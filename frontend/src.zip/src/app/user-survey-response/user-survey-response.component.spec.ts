import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserSurveyResponseComponent } from './user-survey-response.component';

describe('UserSurveyResponseComponent', () => {
  let component: UserSurveyResponseComponent;
  let fixture: ComponentFixture<UserSurveyResponseComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UserSurveyResponseComponent]
    });
    fixture = TestBed.createComponent(UserSurveyResponseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
