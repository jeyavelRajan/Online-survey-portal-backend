export class Reports{
    reportId!:number;
    topicId!:number;
    userId!:number;
}