export class surveyQuestions{
    surveyId!:number;
    topicId!:number;
    survey!:string;
    firstOption!:string;
    secondOption!:string;
    thirdOption!:string;
    fourthOption!:string;
    answer!:string;

    
}