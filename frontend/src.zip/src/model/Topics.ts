export class topics{
    topicId!: number;
    topicName!: string;
}