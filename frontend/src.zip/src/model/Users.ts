export class Users{
    userId! : number;
    firstName! : String;
    lastName! : String;
    emailId! : String;
    phoneNo! : String;
    userName! : String;
    userType! : String;
    password! : String;

}
